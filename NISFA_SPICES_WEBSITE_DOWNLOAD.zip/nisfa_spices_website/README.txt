NISFA SPICES CO. — FREE WEBSITE STARTER
========================================
Included: index.html (complete responsive product website with editable product list, cart, WhatsApp order flow).

PRODUCTS INCLUDED (prices per kg):
Mirchi ₹500; Haldi ₹400; Dhaniya ₹300; Zeera ₹800; Marich ₹1200; Mix Masala ₹500.

IMPORTANT:
- WhatsApp orders work only after you replace 91XXXXXXXXXX in index.html with your number (country code + number, digits only).
- Product prices and names can be edited in the products array near the bottom of index.html.
- This starter has a cart and WhatsApp order handoff, but does not process online payments.
- This file package does not buy a domain or publish the website automatically.

OPEN / TEST:
1. Extract ZIP.
2. Open index.html in Chrome.
3. For WhatsApp order testing, first set the number in the file.

FREE PUBLISHING:
1. Create an account at https://github.com/
2. Create a PUBLIC repository named nisfa-spices-website.
3. Upload index.html to the repository root.
4. Repository Settings -> Pages -> deploy from branch -> main -> /(root) -> Save.
5. The free site URL will be shown by GitHub Pages after publishing.
6. A custom .com domain is not free. You can connect one later if you buy it.

EDIT PRICES:
Open index.html in a text editor and find:
const products=[
Change price numbers only. Example: {id:1,name:"Mirchi",price:500,emoji:"🌶️"}
Keep prices as numbers without ₹ or commas.

This is a starter template. Confirm actual pack size, product details, delivery, returns and food compliance before taking customer orders.

PRODUCT PHOTOS:
- The assets/ folder contains six illustrative spice photos cropped from a generated website concept image.
- They are illustrative spice photos, not verified photos of your exact product/batch or packaging. Replace them with your own actual product photos when possible.
- Keep the assets folder next to index.html when uploading to GitHub Pages.
